package com.cfc.ejemplo17_acelerometro;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    SensorManager sensorManager = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensores = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
        if (sensores.size() > 0){
            sensorManager.registerListener(this, sensores.get(0),
                    SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onStop() {
        sensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        double nuevoX = event.values[0];
        double nuevoY = event.values[1];
        double nuevoZ = event.values[2];

        TextView etiqueta_X = findViewById(R.id.text_X);
        TextView etiqueta_Y = findViewById(R.id.text_Y);
        TextView etiqueta_Z = findViewById(R.id.text_Z);

        etiqueta_X.setText("Valor X: " + nuevoX);
        etiqueta_Y.setText("Valor Y: " + nuevoY);
        etiqueta_Z.setText("Valor Z: " + nuevoZ);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}