package com.cfc.ejemplo16_obtenersensores;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obteniendo la referencia a la etiqueta
        TextView etiqueta = findViewById(R.id.label);

        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Solicitamos la lista de todos los sensores de nuestro dispositivo
        List<Sensor> sensores = sensorManager.getSensorList(Sensor.TYPE_ALL);

        // Recorremos la lista de sensores y lo mostramos en la etiqueta
        for (Sensor sensor : sensores){
            //etiqueta.setText(etiqueta.getText() + "      ");
            etiqueta.append(sensor.getName() + "\n");
        }
    }
}