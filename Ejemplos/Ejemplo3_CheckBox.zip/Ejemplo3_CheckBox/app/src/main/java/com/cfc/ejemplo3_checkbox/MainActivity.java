package com.cfc.ejemplo3_checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onCheckboxClicked(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.checkbox_cine:
                Toast.makeText(getApplicationContext(), "Cine", Toast.LENGTH_SHORT).show();
                break;

            case R.id.checkbox_circo:
                Toast.makeText(getApplicationContext(), "Circo", Toast.LENGTH_SHORT).show();
                break;

            case R.id.checkbox_museos:
                Toast.makeText(getApplicationContext(), "Museos", Toast.LENGTH_SHORT).show();
                break;

            case R.id.checkbox_teatro:
                Toast.makeText(getApplicationContext(), "Teatro", Toast.LENGTH_SHORT).show();
                break;

            default:
                break;
        }

    }
}