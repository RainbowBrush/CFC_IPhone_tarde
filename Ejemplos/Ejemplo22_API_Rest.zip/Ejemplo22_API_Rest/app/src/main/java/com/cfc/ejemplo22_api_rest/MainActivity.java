package com.cfc.ejemplo22_api_rest;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.cfc.ejemplo22_api_rest.models.Post;
import com.cfc.ejemplo22_api_rest.services.PostAPI;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        PostAPI postAPI = retrofit.create(PostAPI.class);

        // Buscar uno
        /*
        Call<Post> call = postAPI.buscar(2);

        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                Post post = response.body();
                System.out.println(post);
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                Log.e("ERROR","Error en el servicio",t);
            }
        });
        */


        // Consultar todos
        List<String> lista_post = new ArrayList();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, lista_post);
        ListView lista = findViewById(R.id.list);
        lista.setAdapter(arrayAdapter);

        Call<List<Post>> call = postAPI.todos();

        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                for(Post post : response.body()){
                    lista_post.add(post.getTitle());
                }
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                Log.e("ERROR","Error en el servicio",t);
            }
        });

    }
}