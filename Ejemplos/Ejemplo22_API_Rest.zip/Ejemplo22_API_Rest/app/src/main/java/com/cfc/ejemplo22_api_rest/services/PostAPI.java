package com.cfc.ejemplo22_api_rest.services;

import com.cfc.ejemplo22_api_rest.models.Post;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface PostAPI {

    @GET("/posts")
    Call<List<Post>> todos();

    @GET("/posts/{codigo}")
    Call<Post> buscar(@Path("codigo") int codigo);

    @FormUrlEncoded
    @POST("/posts")
    Call<ResponseBody> nuevo( @Field("userId") int userId,
                              @Field("id") int id,
                              @Field("title") String title,
                              @Field("body") String body);

    @DELETE("/posts/{codigo}")
    Call<Post> eliminar(@Path("codigo") int codigo);

    @FormUrlEncoded
    @PUT("/posts")
    Call<ResponseBody> modificar( @Field("userId") int userId,
                              @Field("id") int id,
                              @Field("title") String title,
                              @Field("body") String body);

}
