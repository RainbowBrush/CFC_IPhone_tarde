package com.cfc.ejemplo22_api_rest.services;

import com.cfc.ejemplo22_api_rest.models.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PostAPI {

    @GET("/posts")
    Call<List<Post>> todos();

}
