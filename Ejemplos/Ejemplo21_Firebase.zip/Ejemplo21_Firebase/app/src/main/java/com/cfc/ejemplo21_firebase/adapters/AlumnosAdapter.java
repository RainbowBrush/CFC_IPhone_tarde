package com.cfc.ejemplo21_firebase.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cfc.ejemplo21_firebase.models.Alumno;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class AlumnosAdapter extends RecyclerView.Adapter<AlumnoHolder> {

    private List<Alumno> alumnos;
    private int itemLayout;

    public AlumnosAdapter(List<Alumno> alumnos, int itemLayout) {
        this.alumnos = alumnos;
        this.itemLayout = itemLayout;
    }

    @Override
    public AlumnoHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(itemLayout,parent,false);
        return new AlumnoHolder(view);
    }

    @Override
    public void onBindViewHolder(AlumnoHolder holder, int position) {
        Alumno alumno = alumnos.get(position);
        holder.setNombre(alumno.getNombre());
        holder.setNota(alumno.getNota());
    }

    @Override
    public int getItemCount() {
        return alumnos.size();
    }
}
