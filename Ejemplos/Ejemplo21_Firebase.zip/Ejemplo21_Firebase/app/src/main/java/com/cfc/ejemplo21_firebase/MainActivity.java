package com.cfc.ejemplo21_firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.cfc.ejemplo21_firebase.adapters.AlumnosAdapter;
import com.cfc.ejemplo21_firebase.models.Alumno;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    FirebaseFirestore db = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = FirebaseFirestore.getInstance();
    }

    public void consultarTodos(View view){
        List<Alumno> lista = new ArrayList<>();
        db.collection("alumnos")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot document: task.getResult()){
                                Alumno alumno = document.toObject(Alumno.class);
                                String nombre = alumno.getNombre();
                                double nota = alumno.getNota();
                                lista.add(alumno);
                            }
                            mostrar(lista);
                        } else {
                            Log.e("ERROR","Error al consultar todos los alumnos ", task.getException());
                        }
                    }
                });
    }

    public void buscar(View view){
        List<Alumno> lista = new ArrayList<>();
        db.collection("alumnos")
                .whereEqualTo("nombre","Maria")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot document: task.getResult()){
                                Alumno alumno = document.toObject(Alumno.class);
                                String nombre = alumno.getNombre();
                                double nota = alumno.getNota();
                                lista.add(alumno);
                            }
                            mostrar(lista);
                        } else {
                            Log.e("ERROR","Error al consultar todos los alumnos ", task.getException());
                        }
                    }
                });
    }

    public void alta(View view){
        Map<String,Object> alumno = new HashMap<>();
        alumno.put("nombre","AlumnoNuevo");
        alumno.put("nota",10);

        db.collection("alumnos")
                .add(alumno)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                       Log.i("OK","Alumno nuevo insertado");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e("ERROR","Error al insertar alumno",e);
                    }
                });
    }

    public void eliminar(View view){
        db.collection("alumnos").document("a7uuMR54MMdhmbjuPQQJ")
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void valor) {
                        Log.i("OK","Alumno eliminado");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e("ERROR","Error al borrar alumno",e);
                    }
                });
    }

    public void modificar(View view){
        Map<String,Object> alumno = new HashMap<>();
        alumno.put("nombre","Manuel");
        alumno.put("nota",8);

        db.collection("alumnos").document("rvsk3tFAqeHmOuNYp6DK")
                .update(alumno)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void valor) {
                        Log.i("OK","Alumno modificado");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.e("ERROR","Error al modificar alumno",e);
                    }
                });
    }

    private void mostrar(List<Alumno> lista){
        RecyclerView recyclerView = findViewById(R.id.lstAlumnos);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(new AlumnosAdapter(lista,R.layout.item_lista));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }


}