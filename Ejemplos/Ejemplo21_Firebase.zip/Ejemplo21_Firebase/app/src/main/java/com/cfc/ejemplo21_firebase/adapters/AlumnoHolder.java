package com.cfc.ejemplo21_firebase.adapters;

import android.view.View;
import android.widget.TextView;

import com.cfc.ejemplo21_firebase.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AlumnoHolder  extends RecyclerView.ViewHolder {

    // Almacenamos item_lista.xml
    private View view;

    public AlumnoHolder(View itemView) {
        super(itemView);
        this.view = itemView;
    }

    public void setNombre(String nombre){
        TextView labelNombre = view.findViewById(R.id.nombreAlum);
        labelNombre.setText(nombre);
    }

    public void setNota(double nota){
        TextView labelNota = view.findViewById(R.id.notaAlum);
        labelNota.setText(String.valueOf(nota));
    }
}
