package com.cfc.ejemplo1_helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SaludoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        // Buscar la etiqueta en la UI
        TextView etiqueta = findViewById(R.id.lblMensaje);

        // Recuperar el nombre recibido
        String nombre = getIntent().getExtras().getString("userName");

        etiqueta.setText("Hola " + nombre);
    }
}