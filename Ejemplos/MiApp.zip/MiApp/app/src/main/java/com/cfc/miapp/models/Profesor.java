package com.cfc.miapp.models;

public class Profesor {

    private String nombre;
    private String perfil;
    private String experiencia;

    public Profesor() {
    }

    public Profesor(String nombre, String perfil, String experiencia) {
        this.nombre = nombre;
        this.perfil = perfil;
        this.experiencia = experiencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public String getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(String experiencia) {
        this.experiencia = experiencia;
    }
}
