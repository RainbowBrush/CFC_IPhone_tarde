package com.cfc.miapp.persistencia;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cfc.miapp.models.Curso;

import java.util.ArrayList;
import java.util.List;

public class CursosDAO {

    private Context context;
    private SQLiteDatabase db;

    public CursosDAO(Context context) {
        this.context = context;
    }

    private void abrirConexion(){
        GestionBBDD gestionBBDD = new GestionBBDD(context,"CFCDB2",null,1);
        db = gestionBBDD.getWritableDatabase();
    }

    private void cerrarConexion(){
        db.close();
    }

    public List<Curso> consultarTodos(){
        List<Curso> lista = new ArrayList<>();
        abrirConexion();

        Cursor cursor = db.rawQuery("select * from Cursos",null);

        while(cursor.moveToNext()){
            lista.add(new Curso(cursor.getString(1),
                    cursor.getInt(2), cursor.getDouble(3)));
        }

        cerrarConexion();
        return lista;
    }
}
