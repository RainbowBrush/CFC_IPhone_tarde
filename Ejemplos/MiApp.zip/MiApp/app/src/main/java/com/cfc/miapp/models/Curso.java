package com.cfc.miapp.models;public class Curso {
}
