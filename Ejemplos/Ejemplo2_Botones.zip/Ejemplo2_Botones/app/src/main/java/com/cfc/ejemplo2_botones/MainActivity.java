package com.cfc.ejemplo2_botones;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Localizar los controles
        final TextView lblMensaje = (TextView) findViewById(R.id.Label);
        final Button boton1 = (Button) findViewById(R.id.Boton1);
        final ToggleButton boton2 = (ToggleButton) findViewById(R.id.Boton2);
        final ImageButton boton3 = (ImageButton) findViewById(R.id.Boton3);



//		// Add el listener al boton
//		boton1.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				// Mostrar un mensaje en la etiqueta
//				lblMensaje.setText("El boton 1 ha sido pulsado");
//			}
//		});
//
//		// Add el listener al boton
//		boton2.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				if (boton2.isChecked()) {
//					// Mostrar un mensaje en la etiqueta
//					lblMensaje.setText("El boton 2 en modo ON");
//				} else {
//					lblMensaje.setText("El boton 2 en modo OFF");
//				}
//			}
//		});
//
//		// Add el listener al boton
//		boton3.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				// Mostrar un mensaje en la etiqueta
//				lblMensaje.setText("El boton 3 ha sido pulsado");
//			}
//		});

    }

    public void pulsar(View v){
        switch (v.getId()) {
            case R.id.Boton1:
                Toast.makeText(getApplicationContext(), "Has pulsado el boton 1", Toast.LENGTH_SHORT).show();
                break;

            case R.id.Boton2:
                Toast.makeText(getApplicationContext(), "Has pulsado el boton 2", Toast.LENGTH_SHORT).show();
                break;

            case R.id.Boton3:
                Toast.makeText(getApplicationContext(), "Has pulsado el boton 3", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
    }

}