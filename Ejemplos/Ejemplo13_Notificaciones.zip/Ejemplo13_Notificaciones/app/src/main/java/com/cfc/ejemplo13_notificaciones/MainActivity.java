package com.cfc.ejemplo13_notificaciones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void mostrar(View view){
        switch (view.getId()){
            case R.id.toast_defecto:
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "Notificacion defecto", Toast.LENGTH_SHORT);
                toast1.show();
                break;
            case R.id.toast_personalizado:
                Toast toast2 = new Toast(getApplicationContext());
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.mytoast, findViewById(R.id.lytToast));
                toast2.setDuration(Toast.LENGTH_LONG);
                toast2.setView(layout);
                toast2.show();
                break;
            case R.id.toast_barra_estado:
                String CHANNEL_ID = "My_channel_1";
                CharSequence name = "Channel 1";
                int importance = NotificationManager.IMPORTANCE_HIGH;
                NotificationChannel notificationChannel= new
                        NotificationChannel(CHANNEL_ID,name,importance);

                Notification notification = new Notification.Builder(MainActivity.this)
                        .setContentTitle("Tienes un mensaje")
                        .setContentText("Texto del mensaje")
                        .setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setChannelId(CHANNEL_ID)
                        .build();

                NotificationManager notificationManager =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.createNotificationChannel(notificationChannel);

                notificationManager.notify(7,notification);
                break;
            case R.id.dialogo_alerta:
                Alerta alerta = new Alerta();
                FragmentManager fm = getSupportFragmentManager();
                // Para evitar que se cierre fuera del cuadro de dialogo
                alerta.setCancelable(false);
                alerta.show(fm, "Alerta");
                break;
            case R.id.dialogo_confirmacion:
                Confirmacion confirmacion = new Confirmacion();
                fm = getSupportFragmentManager();
                confirmacion.setCancelable(false);
                confirmacion.show(fm, "Confirmacion");
                break;
            case R.id.dialogo_seleccion:
                Seleccion seleccion = new Seleccion();
                fm = getSupportFragmentManager();
                seleccion.setCancelable(false);
                seleccion.show(fm, "Seleccion");
        }

    }
}