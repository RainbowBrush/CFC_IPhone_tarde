package com.cfc.ejemplo13_notificaciones;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class Seleccion extends DialogFragment {

    final String[] items = {"Movil","Casa","Vecino"};

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Selecciona WIFI");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                System.out.println("Wifi seleccionada " + items[which]);
                dialog.cancel();
            }
        });

        return builder.create();
    }
}
