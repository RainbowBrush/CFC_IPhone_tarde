package com.example.ejemplo004_brujula;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView textView;
    private ImageView imageView;
    private SensorManager sensorManager;
    private Sensor accelerometerSensor, magnetometerSensor;
    private float[] lastAccelerometer = new float[3];
    private float[] lastMagnetometer = new float[3];
    private float[] rotationMatrix = new float[9];
    private float[] orientation = new float[3];

    boolean isLastAccelerometerArrayCopied = false;
    boolean isLastMagmetometerArrayCopied = false;

    long lastUpdatedTime = 0;
    long currentDegree = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor == accelerometerSensor) {
            System.arraycopy(event.values, 0, lastAccelerometer, 0,
                    event.values.length);

            isLastAccelerometerArrayCopied = true;
        } else if (event.sensor == magnetometerSensor) {
            System.arraycopy(event.values, 0, lastMagnetometer, 0,
                    event.values.length);

            isLastMagmetometerArrayCopied = true;
        }

        if (isLastAccelerometerArrayCopied && isLastMagmetometerArrayCopied &&
                System.currentTimeMillis() - lastUpdatedTime > 250) {
            sensorManager.getRotationMatrix(rotationMatrix,null,lastAccelerometer,
                    lastMagnetometer);
            sensorManager.getOrientation(rotationMatrix, orientation);

            float azimutInRadiants = orientation[0];
            float azimutInDegree = (float) Math.toDegrees(azimutInRadiants);

            RotateAnimation rotationAnimation = new RotateAnimation(currentDegree,
                    -azimutInDegree, Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);

            rotationAnimation.setDuration(250);
            rotationAnimation.setFillAfter(true);

            imageView.startAnimation(rotationAnimation);

            currentDegree = (long) -azimutInDegree;
            lastUpdatedTime = System.currentTimeMillis();

            int x = (int) azimutInDegree;

            textView.setText(x + "º");
        }
     }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        sensorManager.registerListener(this, accelerometerSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, magnetometerSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();

        sensorManager.unregisterListener(this, accelerometerSensor);
        sensorManager.unregisterListener(this, magnetometerSensor);
    }
}